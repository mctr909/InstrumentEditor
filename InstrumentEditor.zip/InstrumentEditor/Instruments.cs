using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;

using Riff;

namespace Instruments {
    #region enum
    public enum ART_TYPE : ushort {
        GAIN_CONST     = 0x0000,
        GAIN_VALIABLE  = 0x0001,
        PAN_CONST      = 0x0002,
        PAN_VALIABLE   = 0x0003,
        PITCH_CONST    = 0x0004,
        PITCH_VALIABLE = 0x0005,

        COASE_TUNE   = 0x0006,
        OVERRIDE_KEY = 0x0007,

        LPF_RESONANCE       = 0x0008,
        LPF_CUTOFF_CONST    = 0x0009,
        LPF_CUTOFF_VALIABLE = 0x000A,

        EG_AMP_ATTACK  = 0x0100,
        EG_AMP_HOLD    = 0x0101,
        EG_AMP_DECAY   = 0x0102,
        EG_AMP_RELEASE = 0x0103,
        EG_AMP_SUSTAIN = 0x0106,

        EG_CUTOFF_ATTACK  = 0x0110,
        EG_CUTOFF_HOLD    = 0x0111,
        EG_CUTOFF_DECAY   = 0x0112,
        EG_CUTOFF_RELEASE = 0x0113,
        EG_CUTOFF_RISE    = 0x0114,
        EG_CUTOFF_TOP     = 0x0115,
        EG_CUTOFF_SUSTAIN = 0x0116,
        EG_CUTOFF_FALL    = 0x0117,

        INST_INDEX = 0xFFFE,
        WAVE_INDEX = 0xFFFF
    }
    #endregion

    #region struct
    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct WPTR {
        public UInt32 ofsHeader;
        public UInt32 ofsData;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct WAVH {
        public UInt32 SampleRate;
        public UInt32 LoopBegin;
        public UInt32 LoopLength;
        public byte   LoopEnable;
        public byte   UnityNote;
        public UInt16 Reserved;
        public double Gain;
        public double Pitch;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct PREH {
        public byte bankFlg;
        public byte bankMSB;
        public byte bankLSB;
        public byte progNum;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct RANGE {
        public byte keyHi;
        public byte keyLo;
        public byte velHi;
        public byte velLo;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct ART {
        public ART_TYPE type;
        public ushort   reserved;
        public float    value;
    }
    #endregion

    public class File : Chunk {
        public Lwav Wave = new Lwav();
        public Lins Inst = new Lins();
        public Lpre Preset = new Lpre();
        public Info Info = new Info();

        public File() { }

        public File(string filePath) : base(filePath) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "wptr":
                break;
            default:
                break;
            }
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "lwav":
                Wave = new Lwav(ptr, ptrTerm);
                break;
            case "lins":
                Inst = new Lins(ptr, ptrTerm);
                break;
            case "lpre":
                Preset = new Lpre(ptr, ptrTerm);
                break;
            case "INFO":
                Info = new Info(ptr, ptrTerm);
                break;
            default:
                break;
            }
        }

        public void Save(string path) {
            var fs = new FileStream(path, FileMode.Create);
            var bw = new BinaryWriter(fs);

            bw.Write("RIFF".ToCharArray());
            bw.Write(0xFFFFFFFF);
            bw.Write("INST".ToCharArray());

            if (0 < Wave.List.Count) {
                // wptr chunk
                bw.Write("wptr".ToCharArray());
                bw.Write(Marshal.SizeOf<WPTR>() * Wave.List.Count);
                var pos = -8;
                foreach (var wave in Wave.List) {
                    var data = wave.Write();
                    bw.Write((uint)(pos + data.Key.ofsHeader));
                    bw.Write((uint)(pos + data.Key.ofsData));
                    pos += data.Value.Length;
                }

                // lwav list
                bw.Write("LIST".ToCharArray());
                var wavePos = fs.Position;
                bw.Write(0xFFFFFFFF);
                bw.Write("lwav".ToCharArray());
                foreach (var wave in Wave.List) {
                    var data = wave.Write();
                    bw.Write(data.Value, 0, data.Value.Length);
                }
                var waveTerm = fs.Position;
                fs.Seek(wavePos, SeekOrigin.Begin);
                bw.Write((uint)(waveTerm - wavePos - 4));
                fs.Seek(waveTerm, SeekOrigin.Begin);
            }

            Inst.Write(bw);
            Preset.Write(bw);
            Info.Write(bw);

            fs.Seek(4, SeekOrigin.Begin);
            bw.Write((uint)fs.Length - 8);

            fs.Close();
            fs.Dispose();
        }
    }

    public class Lwav : Chunk {
        public List<Wave> List = new List<Wave>();

        public Lwav() { }

        public Lwav(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "wave":
                List.Add(new Wave(ptr, ptrTerm));
                break;
            default:
                break;
            }
        }
    }

    public class Wave : Chunk {
        public WAVH Header;
        public short[] Data = null;
        public Info Info = new Info();

        public Wave() { }

        public Wave(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "wavh":
                Header = Marshal.PtrToStructure<WAVH>(ptr);
                break;
            case "data":
                Data = new short[chunkSize / 2];
                Marshal.Copy(ptr, Data, 0, Data.Length);
                break;
            default:
                break;
            }
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "INFO":
                Info = new Info(ptr, ptrTerm);
                break;
            default:
                break;
            }
        }

        public KeyValuePair<WPTR, byte[]> Write() {
            var msWave = new MemoryStream();
            var bwWave = new BinaryWriter(msWave);
            WPTR wptr;

            bwWave.Write("LIST".ToCharArray());
            bwWave.Write(0xFFFFFFFF);
            bwWave.Write("wave".ToCharArray());

            {
                // wavh chunk
                var size = Marshal.SizeOf<WAVH>();
                bwWave.Write("wavh".ToCharArray());
                bwWave.Write(size);

                wptr.ofsHeader = (uint)msWave.Position;
                var ptr = Marshal.AllocHGlobal(size);
                Marshal.StructureToPtr(Header, ptr, true);
                var arr = new byte[size];
                Marshal.Copy(ptr, arr, 0, size);
                bwWave.Write(arr);
                Marshal.FreeHGlobal(ptr);
            }

            {
                // data chunk
                bwWave.Write("data".ToCharArray());
                bwWave.Write(Data.Length * 2);

                wptr.ofsData = (uint)msWave.Position;
                var ptr = Marshal.AllocHGlobal(Data.Length * 2);
                Marshal.Copy(Data, 0, ptr, Data.Length);
                var arr = new byte[Data.Length * 2];
                Marshal.Copy(ptr, arr, 0, Data.Length * 2);
                bwWave.Write(arr);
                Marshal.FreeHGlobal(ptr);
            }

            Info.Write(bwWave);

            msWave.Seek(4, SeekOrigin.Begin);
            bwWave.Write((uint)msWave.Length - 8);

            return new KeyValuePair<WPTR, byte[]>(wptr, msWave.ToArray());
        }
    }

    public class Lins : Chunk {
        private List<Inst> List = new List<Inst>();

        public Lins() { }

        public Lins(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        public int Count {
            get { return List.Count; }
        }

        public Inst this[int index] {
            get { return List[index]; }
        }

        public void Add(Inst inst) {
            List.Add(inst);
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "inst":
                List.Add(new Inst(ptr, ptrTerm));
                break;
            default:
                break;
            }
        }

        public new void Write(BinaryWriter bw) {
            if (0 == List.Count) {
                return;
            }

            var msInst = new MemoryStream();
            var bwInst = new BinaryWriter(msInst);
            bwInst.Write("LIST".ToCharArray());
            bwInst.Write(0xFFFFFFFF);
            bwInst.Write("lins".ToCharArray());
            foreach (var inst in List) {
                var data = inst.Write();
                bwInst.Write(data.Value, 0, data.Value.Length);
            }
            msInst.Seek(4, SeekOrigin.Begin);
            bwInst.Write((int)msInst.Length - 8);
            bw.Write(msInst.ToArray());
        }
    }

    public class Inst : Chunk {
        public List<ART> Art = new List<ART>();
        public Lrgn Region = new Lrgn();
        public Info Info = new Info();

        public Inst() { }

        public Inst(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "artc":
                for (int ofs = 0; ofs < chunkSize; ofs += Marshal.SizeOf<ART>()) {
                    Art.Add(Marshal.PtrToStructure<ART>(ptr + ofs));
                }
                break;
            default:
                break;
            }
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "lrgn":
                Region = new Lrgn(ptr, ptrTerm);
                break;
            case "INFO":
                Info = new Info(ptr, ptrTerm);
                break;
            default:
                break;
            }
        }

        public KeyValuePair<uint, byte[]> Write() {
            var msInst = new MemoryStream();
            var bwInst = new BinaryWriter(msInst);

            bwInst.Write("LIST".ToCharArray());
            bwInst.Write(0xFFFFFFFF);
            bwInst.Write("inst".ToCharArray());

            if (0 < Art.Count) {
                // artc chunk
                var ms = new MemoryStream();
                var bw = new BinaryWriter(ms);
                bw.Write("artc".ToCharArray());
                bw.Write(Marshal.SizeOf<ART>() * Art.Count);
                foreach (var art in Art) {
                    bw.Write((ushort)art.type);
                    bw.Write((ushort)0);
                    bw.Write(art.value);
                }
                bwInst.Write(ms.ToArray());
            }

            Region.Write(bwInst);
            Info.Write(bwInst);

            msInst.Seek(4, SeekOrigin.Begin);
            bwInst.Write((uint)msInst.Length - 8);
            return new KeyValuePair<uint, byte[]>(0, msInst.ToArray());
        }
    }

    public class Lpre : Chunk {
        private Dictionary<PREH, Preset> List = new Dictionary<PREH, Preset>();

        public Lpre() { }

        public Lpre(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        public int Count {
            get { return List.Count; }
        }

        public Preset this[PREH id] {
            get { return List[id]; }
        }

        public void Add(PREH id, Preset preset) {
            List.Add(id, preset);
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "pres":
                var tmp = new Preset(ptr, ptrTerm);
                List.Add(tmp.Header, tmp);
                break;
            default:
                break;
            }
        }

        public new void Write(BinaryWriter bw) {
            var msPres = new MemoryStream();
            var bwPres = new BinaryWriter(msPres);
            bwPres.Write("LIST".ToCharArray());
            bwPres.Write(0xFFFFFFFF);
            bwPres.Write("lpre".ToCharArray());
            foreach (var pres in List.Values) {
                var data = pres.Write();
                bwPres.Write(data.Value, 0, data.Value.Length);
            }
            msPres.Seek(4, SeekOrigin.Begin);
            bwPres.Write((int)msPres.Length - 8);
            bw.Write(msPres.ToArray());
        }
    }

    public class Preset : Chunk {
        public PREH Header;
        public List<ART> Art = new List<ART>();
        public Llyr Layer = new Llyr();
        public Info Info = new Info();

        public Preset() { }

        public Preset(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "preh":
                Header = Marshal.PtrToStructure<PREH>(ptr);
                break;
            case "artc":
                for (int ofs = 0; ofs < chunkSize; ofs += Marshal.SizeOf<ART>()) {
                    Art.Add(Marshal.PtrToStructure<ART>(ptr + ofs));
                }
                break;
            default:
                break;
            }
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "llyr":
                Layer = new Llyr(ptr, ptrTerm);
                break;
            case "INFO":
                Info = new Info(ptr, ptrTerm);
                break;
            default:
                break;
            }
        }

        public KeyValuePair<uint, byte[]> Write() {
            var msInst = new MemoryStream();
            var bwInst = new BinaryWriter(msInst);

            bwInst.Write("LIST".ToCharArray());
            bwInst.Write(0xFFFFFFFF);
            bwInst.Write("pres".ToCharArray());

            {
                // preh chunk
                var size = Marshal.SizeOf<PREH>();
                bwInst.Write("preh".ToCharArray());
                bwInst.Write(size);
                var ptr = Marshal.AllocHGlobal(size);
                Marshal.StructureToPtr(Header, ptr, true);
                var arr = new byte[size];
                Marshal.Copy(ptr, arr, 0, size);
                bwInst.Write(arr);
            }

            if (0 < Art.Count) {
                // art chunk
                var ms = new MemoryStream();
                var bw = new BinaryWriter(ms);
                bw.Write("artc".ToCharArray());
                bw.Write(Marshal.SizeOf<ART>() * Art.Count);
                foreach (var art in Art) {
                    bw.Write((ushort)art.type);
                    bw.Write((ushort)0);
                    bw.Write(art.value);
                }
                bwInst.Write(ms.ToArray());
            }

            Layer.Write(bwInst);
            Info.Write(bwInst);

            msInst.Seek(4, SeekOrigin.Begin);
            bwInst.Write((uint)msInst.Length - 8);
            return new KeyValuePair<uint, byte[]>(0, msInst.ToArray());
        }
    }

    public class Llyr : Chunk {
        private List<Layer> List = new List<Layer>();

        public Llyr() { }

        public Llyr(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        public int Count {
            get { return List.Count; }
        }

        public Layer this[int index] {
            get { return List[index]; }
        }

        public void Add(Layer layer) {
            List.Add(layer);
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "lyr ":
                break;
            default:
                break;
            }
        }

        public new void Write(BinaryWriter bw) {
            var msLyr = new MemoryStream();
            var bwLyr = new BinaryWriter(msLyr);
            bwLyr.Write("LIST".ToCharArray());
            bwLyr.Write(0xFFFFFFFF);
            bwLyr.Write("llyr".ToCharArray());
            var size = 4;
            foreach (var layer in List) {
                var arr = layer.Write();
                size += arr.Length;
                msLyr.Write(arr, 0, arr.Length);
            }
            bwLyr.Seek(4, SeekOrigin.Begin);
            bwLyr.Write(size);
            bw.Write(msLyr.ToArray());
        }
    }

    public class Layer : Chunk {
        public RANGE Header;
        public List<ART> Art = new List<ART>();

        public Layer() { }

        public Layer(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "lyrh":
                Header = Marshal.PtrToStructure<RANGE>(ptr);
                break;
            case "artc":
                for (int ofs = 0; ofs < chunkSize; ofs += Marshal.SizeOf<ART>()) {
                    Art.Add(Marshal.PtrToStructure<ART>(ptr + ofs));
                }
                break;
            default:
                break;
            }
        }

        public byte[] Write() {
            var msLayer = new MemoryStream();
            var bwLayer = new BinaryWriter(msLayer);

            bwLayer.Write("LIST".ToCharArray());
            bwLayer.Write(0xFFFFFFFF);
            bwLayer.Write("lyr ".ToCharArray());

            {
                // lyrh chunk
                var size = Marshal.SizeOf<RANGE>();
                bwLayer.Write("lyrh".ToCharArray());
                bwLayer.Write(size);
                var ptr = Marshal.AllocHGlobal(size);
                Marshal.StructureToPtr(Header, ptr, true);
                var arr = new byte[size];
                Marshal.Copy(ptr, arr, 0, size);
                bwLayer.Write(arr);
            }

            if (0 < Art.Count) {
                // artc chunk
                bwLayer.Write("artc".ToCharArray());
                bwLayer.Write(Marshal.SizeOf<ART>() * Art.Count);
                foreach (var art in Art) {
                    bwLayer.Write((ushort)art.type);
                    bwLayer.Write((ushort)0);
                    bwLayer.Write(art.value);
                }
            }

            msLayer.Seek(4, SeekOrigin.Begin);
            bwLayer.Write((uint)msLayer.Length - 8);
            return msLayer.ToArray();
        }
    }

    public class Lrgn : Chunk {
        private List<Region> List = new List<Region>();

        public Lrgn() { }

        public Lrgn(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        public int Count {
            get { return List.Count; }
        }

        public Region this[int index] {
            get { return List[index]; }
        }

        public void Add(Region region) {
            List.Add(region);
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "rgn ":
                break;
            default:
                break;
            }
        }

        public new void Write(BinaryWriter bw) {
            if (0 == List.Count) {
                return;
            }

            var msRgn = new MemoryStream();
            var bwRgn = new BinaryWriter(msRgn);
            bwRgn.Write("LIST".ToCharArray());
            bwRgn.Write(0xFFFFFFFF);
            bwRgn.Write("lrgn".ToCharArray());
            var size = 4;
            foreach (var region in List) {
                var arr = region.Write();
                size += arr.Length;
                msRgn.Write(arr, 0, arr.Length);
            }
            bwRgn.Seek(4, SeekOrigin.Begin);
            bwRgn.Write(size);
            bw.Write(msRgn.ToArray());
        }
    }

    public class Region : Chunk {
        public RANGE Header;
        public List<ART> Art = new List<ART>();

        public Region() { }

        public Region(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "rgnh":
                Header = Marshal.PtrToStructure<RANGE>(ptr);
                break;
            case "artc":
                for (int ofs = 0; ofs < chunkSize; ofs += Marshal.SizeOf<ART>()) {
                    Art.Add(Marshal.PtrToStructure<ART>(ptr + ofs));
                }
                break;
            default:
                break;
            }
        }

        public byte[] Write() {
            var ms = new MemoryStream();
            var bw = new BinaryWriter(ms);
            var rgnhSize = Marshal.SizeOf<RANGE>();
            var artSize = Marshal.SizeOf<ART>() * Art.Count;

            if (0 < artSize) {
                bw.Write("LIST".ToCharArray());
                bw.Write(rgnhSize + artSize + 20);
                bw.Write("rgn ".ToCharArray());

                bw.Write("rgnh".ToCharArray());
                bw.Write(rgnhSize);
                var ptr = Marshal.AllocHGlobal(rgnhSize);
                Marshal.StructureToPtr(Header, ptr, true);
                var arr = new byte[rgnhSize];
                Marshal.Copy(ptr, arr, 0, rgnhSize);
                bw.Write(arr);

                bw.Write("artc".ToCharArray());
                bw.Write(artSize);
                foreach(var art in Art) {
                    bw.Write((ushort)art.type);
                    bw.Write((ushort)0);
                    bw.Write(art.value);
                }
            } else {
                bw.Write("LIST".ToCharArray());
                bw.Write(rgnhSize + 12);
                bw.Write("rgn ".ToCharArray());

                bw.Write("rgnh".ToCharArray());
                bw.Write(rgnhSize);
                var ptr = Marshal.AllocHGlobal(rgnhSize);
                Marshal.StructureToPtr(Header, ptr, true);
                var arr = new byte[rgnhSize];
                Marshal.Copy(ptr, arr, 0, rgnhSize);
                bw.Write(arr);
            }

            return ms.ToArray();
        }
    }
}
