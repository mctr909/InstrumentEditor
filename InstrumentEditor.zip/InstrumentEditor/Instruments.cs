using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;

using Riff;

namespace Instruments {
    #region enum
    public enum ART_TYPE : ushort {
        GAIN_CONST     = 0x0000,
        GAIN_VALIABLE  = 0x0001,
        PAN_CONST      = 0x0002,
        PAN_VALIABLE   = 0x0003,
        PITCH_CONST    = 0x0004,
        PITCH_VALIABLE = 0x0005,

        COASE_TUNE   = 0x0006,
        OVERRIDE_KEY = 0x0007,

        LPF_RESONANCE       = 0x0008,
        LPF_CUTOFF_CONST    = 0x0009,
        LPF_CUTOFF_VALIABLE = 0x000A,

        EG_AMP_ATTACK  = 0x0100,
        EG_AMP_HOLD    = 0x0101,
        EG_AMP_DECAY   = 0x0102,
        EG_AMP_RELEASE = 0x0103,
        EG_AMP_SUSTAIN = 0x0106,

        EG_CUTOFF_ATTACK  = 0x0110,
        EG_CUTOFF_HOLD    = 0x0111,
        EG_CUTOFF_DECAY   = 0x0112,
        EG_CUTOFF_RELEASE = 0x0113,
        EG_CUTOFF_RISE    = 0x0114,
        EG_CUTOFF_TOP     = 0x0115,
        EG_CUTOFF_SUSTAIN = 0x0116,
        EG_CUTOFF_FALL    = 0x0117,

        INST_INDEX = 0xFFFE,
        WAVE_INDEX = 0xFFFF
    }
    #endregion

    #region struct
    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct WPTR {
        public UInt32 ofsHeader;
        public UInt32 ofsData;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct WAVH {
        public UInt32 SampleRate;
        public UInt32 LoopBegin;
        public UInt32 LoopLength;
        public byte   LoopEnable;
        public byte   UnityNote;
        public UInt16 Reserved;
        public double Gain;
        public double Pitch;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct PREH {
        public byte bankFlg;
        public byte bankMSB;
        public byte bankLSB;
        public byte progNum;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    public struct RANGE {
        public byte keyHi;
        public byte keyLo;
        public byte velHi;
        public byte velLo;
    }

    [StructLayout(LayoutKind.Sequential, Pack = 8)]
    public struct ART {
        public ART_TYPE type;
        public ushort   reserved;
        public float    value;
    }
    #endregion

    public class File : Chunk {
        public Lwav Wave = new Lwav();
        public Lins Inst = new Lins();
        public Lpre Preset = new Lpre();
        public Info Info = new Info();

        public File() { }

        public File(string filePath) : base(filePath) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "wptr":
                break;
            default:
                break;
            }
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "lwav":
                Wave = new Lwav(ptr, ptrTerm);
                break;
            case "lins":
                Inst = new Lins(ptr, ptrTerm);
                break;
            case "lpre":
                Preset = new Lpre(ptr, ptrTerm);
                break;
            case "INFO":
                Info = new Info(ptr, ptrTerm);
                break;
            default:
                break;
            }
        }

        public void Save(string path) {
            var fs = new FileStream(path, FileMode.Create);
            var bw = new BinaryWriter(fs);

            bw.Write("RIFF".ToCharArray());
            bw.Write(0xFFFFFFFF);
            bw.Write("INST".ToCharArray());

            Wave.Write(fs);
            Inst.Write(bw);
            Preset.Write(bw);
            Info.Write(bw);

            fs.Seek(4, SeekOrigin.Begin);
            bw.Write((uint)fs.Length - 8);

            fs.Close();
            fs.Dispose();
        }
    }

    public class Lwav : Chunk {
        private List<Wave> List = new List<Wave>();

        public Lwav() { }

        public Lwav(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        public int Count {
            get { return List.Count; }
        }

        public Wave this[int index] {
            get { return List[index]; }
        }

        public void Add(Wave wave) {
            List.Add(wave);
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "wave":
                List.Add(new Wave(ptr, ptrTerm));
                break;
            default:
                break;
            }
        }

        public void Write(FileStream fs) {
            if (0 == List.Count) {
                return;
            }

            var bw = new BinaryWriter(fs);

            // wptr chunk
            bw.Write("wptr".ToCharArray());
            bw.Write(Marshal.SizeOf<WPTR>() * List.Count);
            var pos = -8;
            foreach (var wave in List) {
                var data = wave.Write();
                bw.Write((uint)(pos + data.Key.ofsHeader));
                bw.Write((uint)(pos + data.Key.ofsData));
                pos += data.Value.Length;
            }

            // lwav list
            bw.Write("LIST".ToCharArray());
            var wavePos = fs.Position;
            bw.Write(0xFFFFFFFF);
            bw.Write("lwav".ToCharArray());
            foreach (var wave in List) {
                var data = wave.Write();
                bw.Write(data.Value, 0, data.Value.Length);
            }
            var waveTerm = fs.Position;
            fs.Seek(wavePos, SeekOrigin.Begin);
            bw.Write((uint)(waveTerm - wavePos - 4));
            fs.Seek(waveTerm, SeekOrigin.Begin);
        }
    }

    public class Wave : Chunk {
        public WAVH Header;
        public short[] Data = null;
        public Info Info = new Info();

        public Wave() { }

        public Wave(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "wavh":
                Header = Marshal.PtrToStructure<WAVH>(ptr);
                break;
            case "data":
                Data = new short[chunkSize / 2];
                Marshal.Copy(ptr, Data, 0, Data.Length);
                break;
            default:
                break;
            }
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "INFO":
                Info = new Info(ptr, ptrTerm);
                break;
            default:
                break;
            }
        }

        public KeyValuePair<WPTR, byte[]> Write() {
            var msWave = new MemoryStream();
            var bwWave = new BinaryWriter(msWave);
            WPTR wptr;

            bwWave.Write("LIST".ToCharArray());
            bwWave.Write(0xFFFFFFFF);
            bwWave.Write("wave".ToCharArray());

            {
                // wavh chunk
                var size = Marshal.SizeOf<WAVH>();
                bwWave.Write("wavh".ToCharArray());
                bwWave.Write(size);

                wptr.ofsHeader = (uint)msWave.Position;
                var ptr = Marshal.AllocHGlobal(size);
                Marshal.StructureToPtr(Header, ptr, true);
                var arr = new byte[size];
                Marshal.Copy(ptr, arr, 0, size);
                bwWave.Write(arr);
                Marshal.FreeHGlobal(ptr);
            }

            {
                // data chunk
                bwWave.Write("data".ToCharArray());
                bwWave.Write(Data.Length * 2);

                wptr.ofsData = (uint)msWave.Position;
                var ptr = Marshal.AllocHGlobal(Data.Length * 2);
                Marshal.Copy(Data, 0, ptr, Data.Length);
                var arr = new byte[Data.Length * 2];
                Marshal.Copy(ptr, arr, 0, Data.Length * 2);
                bwWave.Write(arr);
                Marshal.FreeHGlobal(ptr);
            }

            Info.Write(bwWave);

            msWave.Seek(4, SeekOrigin.Begin);
            bwWave.Write((uint)msWave.Length - 8);

            return new KeyValuePair<WPTR, byte[]>(wptr, msWave.ToArray());
        }
    }

    public class Lins : Chunk {
        private List<Inst> List = new List<Inst>();

        public Lins() { }

        public Lins(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        public int Count {
            get { return List.Count; }
        }

        public Inst this[int index] {
            get { return List[index]; }
        }

        public void Add(Inst inst) {
            List.Add(inst);
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "inst":
                List.Add(new Inst(ptr, ptrTerm));
                break;
            default:
                break;
            }
        }

        public new void Write(BinaryWriter bw) {
            if (0 == List.Count) {
                return;
            }

            var msInst = new MemoryStream();
            var bwInst = new BinaryWriter(msInst);
            bwInst.Write("LIST".ToCharArray());
            bwInst.Write(0xFFFFFFFF);
            bwInst.Write("lins".ToCharArray());
            foreach (var inst in List) {
                var data = inst.Write();
                bwInst.Write(data.Value, 0, data.Value.Length);
            }
            msInst.Seek(4, SeekOrigin.Begin);
            bwInst.Write((int)msInst.Length - 8);
            bw.Write(msInst.ToArray());
        }
    }

    public class Inst : Chunk {
        public Lart Art = new Lart();
        public Lrgn Region = new Lrgn();
        public Info Info = new Info();

        public Inst() { }

        public Inst(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "artc":
                Art = new Lart(ptr, chunkSize);
                break;
            default:
                break;
            }
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "lrgn":
                Region = new Lrgn(ptr, ptrTerm);
                break;
            case "INFO":
                Info = new Info(ptr, ptrTerm);
                break;
            default:
                break;
            }
        }

        public KeyValuePair<uint, byte[]> Write() {
            var msInst = new MemoryStream();
            var bwInst = new BinaryWriter(msInst);

            bwInst.Write("LIST".ToCharArray());
            bwInst.Write(0xFFFFFFFF);
            bwInst.Write("inst".ToCharArray());

            Art.Write(bwInst);
            Region.Write(bwInst);
            Info.Write(bwInst);

            msInst.Seek(4, SeekOrigin.Begin);
            bwInst.Write((uint)msInst.Length - 8);
            return new KeyValuePair<uint, byte[]>(0, msInst.ToArray());
        }
    }

    public class Lpre : Chunk {
        private Dictionary<PREH, Preset> List = new Dictionary<PREH, Preset>();

        public Lpre() { }

        public Lpre(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        public int Count {
            get { return List.Count; }
        }

        public Preset this[PREH id] {
            get { return List[id]; }
        }

        public void Add(PREH id, Preset preset) {
            List.Add(id, preset);
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "pres":
                var tmp = new Preset(ptr, ptrTerm);
                List.Add(tmp.Header, tmp);
                break;
            default:
                break;
            }
        }

        public new void Write(BinaryWriter bw) {
            var msPres = new MemoryStream();
            var bwPres = new BinaryWriter(msPres);
            bwPres.Write("LIST".ToCharArray());
            bwPres.Write(0xFFFFFFFF);
            bwPres.Write("lpre".ToCharArray());
            foreach (var pres in List.Values) {
                pres.Write(bwPres);
            }
            bwPres.Seek(4, SeekOrigin.Begin);
            bwPres.Write((int)msPres.Length - 8);
            bw.Write(msPres.ToArray());
        }
    }

    public class Preset : Chunk {
        public PREH Header;
        public Lart Art = new Lart();
        public Llyr Layer = new Llyr();
        public Info Info = new Info();

        public Preset() { }

        public Preset(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "preh":
                Header = Marshal.PtrToStructure<PREH>(ptr);
                break;
            case "artc":
                Art = new Lart(ptr, chunkSize);
                break;
            default:
                break;
            }
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "llyr":
                Layer = new Llyr(ptr, ptrTerm);
                break;
            case "INFO":
                Info = new Info(ptr, ptrTerm);
                break;
            default:
                break;
            }
        }

        public new void Write(BinaryWriter bw) {
            var msInst = new MemoryStream();
            var bwInst = new BinaryWriter(msInst);
            bwInst.Write("LIST".ToCharArray());
            bwInst.Write(0xFFFFFFFF);
            bwInst.Write("pres".ToCharArray());

            // preh chunk
            var size = Marshal.SizeOf<PREH>();
            bwInst.Write("preh".ToCharArray());
            bwInst.Write(size);
            var ptr = Marshal.AllocHGlobal(size);
            Marshal.StructureToPtr(Header, ptr, true);
            var arr = new byte[size];
            Marshal.Copy(ptr, arr, 0, size);
            bwInst.Write(arr);

            Art.Write(bwInst);
            Layer.Write(bwInst);
            Info.Write(bwInst);

            msInst.Seek(4, SeekOrigin.Begin);
            bwInst.Write((uint)msInst.Length - 8);
            bw.Write(msInst.ToArray());
        }
    }

    public class Llyr : Chunk {
        private List<Layer> List = new List<Layer>();

        public Llyr() { }

        public Llyr(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        public int Count {
            get { return List.Count; }
        }

        public Layer this[int index] {
            get { return List[index]; }
        }

        public void Add(Layer layer) {
            List.Add(layer);
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "lyr ":
                break;
            default:
                break;
            }
        }

        public new void Write(BinaryWriter bw) {
            var msLyr = new MemoryStream();
            var bwLyr = new BinaryWriter(msLyr);
            bwLyr.Write("LIST".ToCharArray());
            bwLyr.Write(0xFFFFFFFF);
            bwLyr.Write("llyr".ToCharArray());
            foreach (var layer in List) {
                layer.Write(bwLyr);
            }
            bwLyr.Seek(4, SeekOrigin.Begin);
            bwLyr.Write((int)msLyr.Length - 8);
            bw.Write(msLyr.ToArray());
        }
    }

    public class Layer : Chunk {
        public RANGE Header;
        public Lart Art = new Lart();

        public Layer() { }

        public Layer(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "lyrh":
                Header = Marshal.PtrToStructure<RANGE>(ptr);
                break;
            case "artc":
                Art = new Lart(ptr, chunkSize);
                break;
            default:
                break;
            }
        }

        public new void Write(BinaryWriter bw) {
            var msLayer = new MemoryStream();
            var bwLayer = new BinaryWriter(msLayer);

            bwLayer.Write("LIST".ToCharArray());
            bwLayer.Write(0xFFFFFFFF);
            bwLayer.Write("lyr ".ToCharArray());

            // lyrh chunk
            var size = Marshal.SizeOf<RANGE>();
            bwLayer.Write("lyrh".ToCharArray());
            bwLayer.Write(size);
            var ptr = Marshal.AllocHGlobal(size);
            Marshal.StructureToPtr(Header, ptr, true);
            var arr = new byte[size];
            Marshal.Copy(ptr, arr, 0, size);
            bwLayer.Write(arr);

            Art.Write(bwLayer);

            bwLayer.Seek(4, SeekOrigin.Begin);
            bwLayer.Write((uint)msLayer.Length - 8);
            bw.Write(msLayer.ToArray());
        }
    }

    public class Lrgn : Chunk {
        private List<Region> List = new List<Region>();

        public Lrgn() { }

        public Lrgn(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        public int Count {
            get { return List.Count; }
        }

        public Region this[int index] {
            get { return List[index]; }
        }

        public void Add(Region region) {
            List.Add(region);
        }

        protected override void ReadList(IntPtr ptr, IntPtr ptrTerm, string listType) {
            switch (listType) {
            case "rgn ":
                List.Add(new Region(ptr, ptrTerm));
                break;
            default:
                break;
            }
        }

        public new void Write(BinaryWriter bw) {
            if (0 == List.Count) {
                return;
            }

            var msRgn = new MemoryStream();
            var bwRgn = new BinaryWriter(msRgn);
            bwRgn.Write("LIST".ToCharArray());
            bwRgn.Write(0xFFFFFFFF);
            bwRgn.Write("lrgn".ToCharArray());
            foreach (var region in List) {
                region.Write(bwRgn);
            }
            bwRgn.Seek(4, SeekOrigin.Begin);
            bwRgn.Write((int)msRgn.Length - 8);
            bw.Write(msRgn.ToArray());
        }
    }

    public class Lart {
        private List<ART> List = new List<ART>();

        public Lart() { }

        public Lart(IntPtr ptr, int size) {
            for (int ofs = 0; ofs < size; ofs += Marshal.SizeOf<ART>()) {
                List.Add(Marshal.PtrToStructure<ART>(ptr + ofs));
            }
        }

        public int Count {
            get { return List.Count; }
        }

        public ART this[int index] {
            get { return List[index]; }
        }

        public void Add(ART art) {
            List.Add(art);
        }

        public void Write(BinaryWriter bw) {
            var msArt = new MemoryStream();
            var bwArt = new BinaryWriter(msArt);
            bwArt.Write("artc".ToCharArray());
            bwArt.Write(0xFFFFFFFF);
            foreach (var art in List) {
                bwArt.Write((ushort)art.type);
                bwArt.Write((ushort)0);
                bwArt.Write(art.value);
            }
            bwArt.Seek(4, SeekOrigin.Begin);
            bwArt.Write((int)msArt.Length - 8);
            bw.Write(msArt.ToArray());
        }
    }

    public class Region : Chunk {
        public RANGE Header;
        public Lart Art = new Lart();

        public Region() { }

        public Region(IntPtr ptr, IntPtr ptrTerm) : base(ptr, ptrTerm) { }

        protected override void ReadChunk(IntPtr ptr, int chunkSize, string chunkType) {
            switch (chunkType) {
            case "rgnh":
                Header = Marshal.PtrToStructure<RANGE>(ptr);
                break;
            case "artc":
                Art = new Lart(ptr, chunkSize);
                break;
            default:
                break;
            }
        }

        public new void Write(BinaryWriter bw) {
            var msRgn = new MemoryStream();
            var bwRgn = new BinaryWriter(msRgn);
            bwRgn.Write("LIST".ToCharArray());
            bwRgn.Write(0xFFFFFFFF);
            bwRgn.Write("rgn ".ToCharArray());

            // rgnh chunk
            var rgnhSize = Marshal.SizeOf<RANGE>();
            bwRgn.Write("rgnh".ToCharArray());
            bwRgn.Write(rgnhSize);
            var ptr = Marshal.AllocHGlobal(rgnhSize);
            Marshal.StructureToPtr(Header, ptr, true);
            var arr = new byte[rgnhSize];
            Marshal.Copy(ptr, arr, 0, rgnhSize);
            bwRgn.Write(arr);

            Art.Write(bwRgn);

            bwRgn.Seek(4, SeekOrigin.Begin);
            bwRgn.Write((int)msRgn.Length - 8);
            bw.Write(msRgn.ToArray());
        }
    }
}
